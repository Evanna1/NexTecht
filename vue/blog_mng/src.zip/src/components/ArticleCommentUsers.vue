<template>
  <div class="article-comment-users">
    <h2>文章评论用户列表</h2>
    <div v-if="mergedIsLoading" class="loading">
      加载中...
    </div>
    <div v-else>
      <h3>文章 {{ articleId }} 的评论用户</h3>
      <table class="comment-users-table">
        <thead>
          <tr>
            <th>用户ID</th>
            <th>用户名</th>
            <th>评论内容</th>
            <th>评论时间</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="commentUser in commentUsers" :key="commentUser.comment_id">
            <td>{{ commentUser.user_info.id }}</td>
            <td>{{ commentUser.user_info.username }}</td>
            <td>{{ commentUser.comment_content }}</td>
            <td>{{ formatDate(commentUser.comment_create_time) }}</td>
          </tr>
        </tbody>
      </table>
      <button @click="backToList">返回列表</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    articleId: {
      type: [String, Number],
      required: true
    },
    isLoading: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      commentUsers: [],
      localIsLoading: false
    };
  },
  computed: {
    mergedIsLoading() {
      return this.isLoading || this.localIsLoading;
    }
  },
  watch: {
    articleId: {
      immediate: true,
      handler(newVal) {
        if (newVal) {
          this.fetchArticleCommentUsers();
        }
      }
    }
  },
  methods: {
    formatDate(dateString) {
      if (!dateString) return '无';
      const date = new Date(dateString);
      return date.toLocaleString();
    },
    async fetchArticleCommentUsers() {
      this.localIsLoading = true;
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(
          `http://localhost:5000/manager/article/${this.articleId}/comment-users`,
          {
            headers: {
              'Authorization': 'Bearer ' + token
            }
          }
        );
        if (response.data.state === 1) {
          this.commentUsers = response.data.comment_users;
        }
      } catch (error) {
        console.error('获取文章评论用户列表失败:', error);
        alert('获取文章评论用户列表失败，请稍后再试');
      } finally {
        this.localIsLoading = false;
      }
    },
    backToList() {
      this.$emit('back-to-list');
    }
  }
};
</script>

<style scoped>
.article-comment-users {
  padding: 20px;
  background-color: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  text-align: left;
}

.loading {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 200px;
  font-size: 16px;
  color: #666;
}

.comment-users-table {
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
  font-size: 14px;
  color: #333;
  margin-bottom: 20px;
}

.comment-users-table th,
.comment-users-table td {
  padding: 8px 10px;
  text-align: left;
  border-bottom: 1px solid #eee;
}

.comment-users-table th {
  background-color: #f2f2f2;
  font-weight: 600;
  color: #555;
}

.comment-users-table tbody tr:nth-child(even) {
  background-color: #f9f9f9;
}

button {
  background-color: #5ea8da;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease;
  margin-top: 20px;
}

button:hover {
  background-color: #4a90c2;
}
</style>