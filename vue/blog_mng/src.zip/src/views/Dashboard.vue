<template>
  <div class="dashboard-wrapper">
    <div class="dashboard-container">
      <Sidebar 
        @show-profile="showSection('profile')" 
        @show-managers="showSection('managers')" 
        @show-users="showSection('users')" 
        @show-articles="showSection('articles')" 
      />
      
      <div class="dashboard-content">
        <Profile 
          v-if="currentView === 'profile'"
          :profile="profile" 
          :isLoading="isLoading" 
          @profile-updated="loadProfile"
        />
        <UserTable 
          v-if="currentView === 'users'" 
          :users="users" 
          :isLoading="isLoading" 
          @refresh-users="loadUsers"
          @show-followers="showFollowers"
          @show-following="showFollowing"
        />
        <div v-if="currentView === 'managers' && isAdmin">
          <ManagerTable 
            :managers="managers" 
            :isLoading="isLoading" 
            @delete-manager="deleteManager" 
            @add-manager="addManager"
            @refresh-managers="loadManagers" 
          />
        </div>
        <div v-if="currentView === 'managers' && !isAdmin">
          <p>权限不足，无法查看管理员列表</p>
        </div>
        <ArticleTable 
          v-if="currentView === 'articles' && !currentArticleId && !currentFavoritesArticleId && !currentCommentArticleId && !currentLikeArticleId && !currentBrowseArticleId" 
          :articles="articles" 
          :isLoading="isLoading" 
          :loadArticles="loadArticles"
          @change-permission="changeArticlePermission"
          @show-articleDetail="showArticleDetail"
          @show-articleFavorites="showArticleFavorites"
          @show-articleCommentUsers="showArticleCommentUsers"
          @show-articleLikeUsers="showArticleLikeUsers"
          @show-articleBrowsers="showArticleBrowsers"
        />
        <ArticleDetail 
          v-if="currentView === 'articles' && currentArticleId" 
          :articleId="currentArticleId"
          :isLoading="isLoading"
          @back-to-list="backToList"
        />
        <ArticleFavorites 
          v-if="currentView === 'articles' && currentFavoritesArticleId" 
          :articleId="currentFavoritesArticleId"
          :isLoading="isLoading"
          @back-to-list="backToList"
        />
        <ArticleCommentUsers 
          v-if="currentView === 'articles' && currentCommentArticleId" 
          :articleId="currentCommentArticleId"
          :isLoading="isLoading"
          @back-to-list="backToList"
        />
        <ArticleLikeUsers 
          v-if="currentView === 'articles' && currentLikeArticleId" 
          :articleId="currentLikeArticleId"
          :isLoading="isLoading"
          @back-to-list="backToList"
        />
        <ArticleBrowsers 
          v-if="currentView === 'articles' && currentBrowseArticleId" 
          :articleId="currentBrowseArticleId"
          :isLoading="isLoading"
          @back-to-list="backToList"
        />
        <!-- 粉丝列表 -->
        <UserFollowList 
          v-if="currentView === 'followers'" 
          :userId="currentUserId"
          :isFollowers="true"
          :ownerUsername="currentUser.username"
          :ownerId="currentUserId"
          @back-to-users="backToUsers"
        />
        <!-- 关注列表 -->
        <UserFollowList 
          v-if="currentView === 'following'" 
          :userId="currentUserId"
          :isFollowers="false"
          :ownerUsername="currentUser.username"
          :ownerId="currentUserId"
          @back-to-users="backToUsers"
        />
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Sidebar from '../components/Sidebar.vue';
import Profile from '../components/Profile.vue';
import UserTable from '../components/UserTable.vue';
import ManagerTable from '../components/ManagerTable.vue';
import ArticleTable from '../components/ArticleTable.vue';
import UserFollowList from '../components/UserFollowList.vue';
import ArticleDetail from '../components/ArticleDetail.vue';
import ArticleFavorites from '../components/ArticleFavorites.vue';
import ArticleCommentUsers from '../components/ArticleCommentUsers.vue';
import ArticleLikeUsers from '../components/ArticleLikeUsers.vue';
import ArticleBrowsers from '../components/ArticleBrowsers.vue';

export default {
  components: {
    Sidebar,
    Profile,
    UserTable,
    ManagerTable,
    ArticleTable,
    UserFollowList,
    ArticleDetail,
    ArticleFavorites,
    ArticleCommentUsers,
    ArticleLikeUsers,
    ArticleBrowsers
  },
  data() {
    return {
      isLoading: false,
      currentView: 'profile',
      profile: {},
      users: [],
      managers: [],
      articles: [],
      isAdmin: false,
      currentUserId: null,
      currentUser: {},
      currentArticleId: null,
      currentFavoritesArticleId: null,
      currentCommentArticleId: null,
      currentLikeArticleId: null,
      currentBrowseArticleId: null // 用于存储当前查看浏览者列表的文章ID
    };
  },
  created() {
    this.loadProfile();
    this.checkAdminStatus();
  },
  methods: {
    showSection(section) {
      if (section === 'managers' && !this.isAdmin) {
        alert('权限不足，无法查看管理员列表');
        return;
      }
      this.currentView = section;
      this.loadDataForSection(section);
    },
    checkAdminStatus() {
      const currentMngId = localStorage.getItem('currentMngId');
      if (currentMngId) {
        this.isAdmin = currentMngId === '1';
      } else if (this.profile && this.profile.mng_id) {
        this.isAdmin = this.profile.mng_id === 1;
      } else {
        this.isAdmin = false;
      }
    },
    loadDataForSection(section) {
      switch(section) {
        case 'profile':
          this.loadProfile();
          break;
        case 'managers':
          if (this.isAdmin) {
            this.loadManagers();
          } else {
            alert('权限不足，无法查看管理员列表');
          }
          break;
        case 'users':
          this.loadUsers();
          break;
        case 'articles':
          this.loadArticles();
          break;
      }
    },
    async loadProfile() {
      try {
        const token = localStorage.getItem('token'); 
        const response = await axios.get('http://localhost:5000/manager/profile', {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        });
        const data = response.data;
        if (data.state === 1) {
          this.profile = data.profile;
          if (this.isAdmin === false && this.profile.mng_id) {
            this.isAdmin = this.profile.mng_id === 1;
          }
        } else {
          console.error('获取管理员信息失败:', data.message);
        }
      } catch (error) {
        console.error('请求管理员信息接口失败:', error);
      }
    },
    async loadManagers() {
      if (!this.isAdmin) {
        alert('权限不足，无法查看管理员列表');
        return;
      }
      try {
        const token = localStorage.getItem('token'); 
        const response = await axios.get('http://localhost:5000/manager/manager_list', {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        });
        const data = response.data;
        if (data.state === 1) {
          this.managers = data.managers;
        } else {
          console.error('获取管理员列表失败:', data.message);
        }
      } catch (error) {
        console.error('请求管理员列表接口失败:', error);
      }
    },
    async loadUsers() {
      try {
        const token = localStorage.getItem('token'); 
        const response = await axios.get('http://localhost:5000/manager/user_list', {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        });
        const data = response.data;
        console.log(data);
        if (data.state === 1) {
          this.users = data.users;
        } else {
          console.error('获取用户列表失败:', data.message);
        }
      } catch (error) {
        console.error('请求用户列表接口失败:', error);
      }
    },
    async loadArticles() {
      this.isLoading = true;
      try {
        const token = localStorage.getItem('token'); 
        const response = await axios.get('http://localhost:5000/manager/article_list', {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        });
        const data = response.data;
        console.log(data);
        if (data.state === 1) {
          this.articles = data.articles;
        } else {
          console.error('获取文章列表失败:', data.message);
        }
      } catch (error) {
        console.error('请求文章列表接口失败:', error);
      } finally {
        this.isLoading = false;
      }
    },
    showFollowers(userId) {
      this.currentUserId = userId;
      this.currentView = 'followers';
      this.getCurrentUser(userId);
    },
    showFollowing(userId) {
      this.currentUserId = userId;
      this.currentView = 'following';
      this.getCurrentUser(userId);
    },
    showArticleDetail(articleId) {
      this.currentArticleId = articleId;
    },
    showArticleFavorites(articleId) {
      this.currentFavoritesArticleId = articleId;
    },
    showArticleCommentUsers(articleId) {
      this.currentCommentArticleId = articleId;
    },
    showArticleLikeUsers(articleId) {
      this.currentLikeArticleId = articleId;
    },
    showArticleBrowsers(articleId) {
      this.currentBrowseArticleId = articleId;
    },
    backToList() {
      this.currentArticleId = null;
      this.currentFavoritesArticleId = null;
      this.currentCommentArticleId = null;
      this.currentLikeArticleId = null;
      this.currentBrowseArticleId = null;
    },
    async getCurrentUser(userId) {
      try {
        const token = localStorage.getItem('token'); 
        const response = await axios.get(`http://localhost:5000/manager/user/${userId}`, {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        });
        const data = response.data;
        if (data.state === 1) {
          this.currentUser = data.user;
        } else {
          console.error('获取用户信息失败:', data.message);
        }
      } catch (error) {
        console.error('请求用户信息接口失败:', error);
      }
    },
    backToUsers() {
      this.currentView = 'users';
    },
    async changeArticlePermission() {
      this.currentArticle.permission = this.permissionForm.new_permission;
    }
  }
}
</script>

<style scoped>
.dashboard-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #e0e7ef;
  display: flex;
  justify-content: flex-start;
  align-items: stretch;
  padding-left: 0;
}

.dashboard-container {
  display: flex;
  width: 100%;
  height: 100%;
  border-radius: 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(219, 11, 11, 0.1);
  background-color: #fff;
}

/* Sidebar 左侧栏 */
.sidebar {
  width: 260px;
  background-color: #2c3e50;
  color: white;
  padding: 30px 20px;
  display: flex;
  flex-direction: column;
  height: 100%;
}

/* 内容区域 */
.dashboard-content {
  flex: 1;
  padding: 30px;
  overflow-y: auto;
  background-color: #f9fbfd;
  height: 100%;
}
</style>